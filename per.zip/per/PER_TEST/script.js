async function getMeishiki() {

  const result = document.getElementById("debugResult");

  const csvUrl = "./master_60.csv";

  try {

    const res = await fetch(csvUrl);

    if (!res.ok) {
      throw new Error("HTTP " + res.status);
    }

    const text = await res.text();

    if (result) {
      result.textContent = text;
    }

    console.log("CSV取得成功");
    console.log(text);

  } catch (err) {

    console.error(err);

    if (result) {
      result.textContent = "取得できませんでした。\n" + err.message;
    }

    alert("取得できませんでした。\n" + err.message);

  }

}

window.addEventListener("DOMContentLoaded", () => {

  document
    .getElementById("btnFetch")
    .addEventListener("click", getMeishiki);

});